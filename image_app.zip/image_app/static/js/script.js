// small interactive touches
document.addEventListener("DOMContentLoaded", function(){
  // animate flash messages away after 4s
  const flashes = document.querySelectorAll(".flash");
  if(flashes.length){
    setTimeout(()=> {
      flashes.forEach(el => {
        el.style.transition = "opacity .6s ease, transform .6s ease";
        el.style.opacity = 0;
        el.style.transform = "translateY(-8px)";
      });
    }, 4200);
  }
});

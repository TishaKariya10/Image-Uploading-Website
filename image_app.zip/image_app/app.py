import os
import sqlite3
import hashlib
import time
import random
import string
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_from_directory, abort

# ------------------ CONFIG ------------------
app = Flask(__name__)
app.secret_key = "supersecretkey"  # change in production

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "uploads")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}
DATABASE = os.path.join(BASE_DIR, "database.db")

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ------------------ UTILITIES ------------------
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def secure_filename_custom(filename: str) -> str:
    # simple replacement: keep alnum and few chars, replace others with _
    name = filename.replace(" ", "_")
    keep = []
    for ch in name:
        if ch.isalnum() or ch in ("-", "_", "."):
            keep.append(ch)
        else:
            keep.append("_")
    cleaned = "".join(keep)
    # prefix with timestamp + random to make unique
    rand = "".join(random.choices(string.ascii_lowercase + string.digits, k=6))
    prefix = str(int(time.time()))
    return f"{prefix}_{rand}_{cleaned}"

# ------------------ DATABASE ------------------
def init_db():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    # users table: id, username(unique), password(hashed), is_admin (0/1), created_at
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        is_admin INTEGER DEFAULT 0,
        created_at TEXT
    )
    """)

    # create default admin (username: admin, password: admin123) if not exists
    admin_pw = hash_password("admin123")
    cursor.execute("SELECT id FROM users WHERE username=?", ("admin",))
    if not cursor.fetchone():
        cursor.execute(
            "INSERT INTO users (username, password, is_admin, created_at) VALUES (?, ?, ?, ?)",
            ("admin", admin_pw, 1, datetime.utcnow().isoformat())
        )

    # images table: id, filename, uploaded_by(username), uploaded_at
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS images (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT NOT NULL,
        uploaded_by TEXT NOT NULL,
        uploaded_at TEXT
    )
    """)

    conn.commit()
    conn.close()

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# ------------------ ROUTES ------------------
@app.route("/")
def index():
    # require login; if not logged -> redirect to login
    if "username" not in session:
        return redirect(url_for("login"))
    conn = get_db_connection()
    images = conn.execute("SELECT * FROM images ORDER BY uploaded_at DESC").fetchall()
    conn.close()
    return render_template("home.html", images=images, username=session.get("username"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if "username" in session:
        return redirect(url_for("index"))

    if request.method == "POST":
        username = request.form.get("username").strip()
        password = request.form.get("password")

        if not username or not password:
            flash("All fields are required", "danger")
            return redirect(url_for("register"))

        conn = get_db_connection()

        try:
            conn.execute(
                "INSERT INTO users (username, password, is_admin, created_at) VALUES (?, ?, ?, ?)",
                (username, hash_password(password), 0, datetime.utcnow().isoformat())
            )
            conn.commit()
            flash("Registration successful! Please login.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Username already taken!", "danger")
        finally:
            conn.close()

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if "username" in session:
        return redirect(url_for("index"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        
        conn = get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        conn.close()

        if user and user["password"] == hash_password(password):
            session["username"] = username
            session["is_admin"] = bool(user["is_admin"])
            flash("Logged in!", "success")
            return redirect(url_for("index"))
        else:
            flash("Invalid username or password!", "danger")

    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out", "info")
    return redirect(url_for("login"))

@app.route("/upload", methods=["GET", "POST"])
def upload():
    if "username" not in session:
        flash("Login required", "warning")
        return redirect(url_for("login"))

    if request.method == "POST":
        file = request.files.get("file")
        if not file or file.filename == "":
            flash("No file selected", "danger")
            return redirect(url_for("upload"))

        if not allowed_file(file.filename):
            flash("Invalid file type", "danger")
            return redirect(url_for("upload"))

        filename = secure_filename_custom(file.filename)
        save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(save_path)

        conn = get_db_connection()
        conn.execute("INSERT INTO images (filename, uploaded_by, uploaded_at) VALUES (?, ?, ?)",
                     (filename, session["username"], datetime.utcnow().isoformat()))
        conn.commit()
        conn.close()

        flash("Image uploaded!", "success")
        return redirect(url_for("index"))

    return render_template("upload.html")

@app.route("/update/<int:image_id>", methods=["GET", "POST"])
def update(image_id):
    if "username" not in session:
        flash("Login required", "warning")
        return redirect(url_for("login"))

    conn = get_db_connection()
    image = conn.execute("SELECT * FROM images WHERE id=?", (image_id,)).fetchone()
    if not image:
        conn.close()
        abort(404)

    # allow only uploader or admin to update
    if image["uploaded_by"] != session["username"] and not session.get("is_admin"):
        conn.close()
        flash("Permission denied", "danger")
        return redirect(url_for("index"))

    if request.method == "POST":
        file = request.files.get("file")
        if not file or file.filename == "":
            flash("No file selected", "danger")
            conn.close()
            return redirect(url_for("update", image_id=image_id))

        if not allowed_file(file.filename):
            flash("Invalid file type", "danger")
            conn.close()
            return redirect(url_for("update", image_id=image_id))

        # delete old file
        old_path = os.path.join(app.config["UPLOAD_FOLDER"], image["filename"])
        if os.path.exists(old_path):
            try:
                os.remove(old_path)
            except Exception:
                pass

        new_filename = secure_filename_custom(file.filename)
        file.save(os.path.join(app.config["UPLOAD_FOLDER"], new_filename))

        conn.execute("UPDATE images SET filename=?, uploaded_at=? WHERE id=?",
                     (new_filename, datetime.utcnow().isoformat(), image_id))
        conn.commit()
        conn.close()
        flash("Image updated", "success")
        return redirect(url_for("index"))

    conn.close()
    return render_template("update.html", image=image)

@app.route("/delete/<int:image_id>", methods=["POST"])
def delete(image_id):
    if "username" not in session:
        flash("Login required", "warning")
        return redirect(url_for("login"))

    conn = get_db_connection()
    image = conn.execute("SELECT * FROM images WHERE id=?", (image_id,)).fetchone()
    if not image:
        conn.close()
        flash("Image not found", "danger")
        return redirect(url_for("index"))

    # allow only uploader or admin to delete
    if image["uploaded_by"] != session["username"] and not session.get("is_admin"):
        conn.close()
        flash("Permission denied", "danger")
        return redirect(url_for("index"))

    # delete file
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], image["filename"])
    if os.path.exists(file_path):
        try:
            os.remove(file_path)
        except Exception:
            pass

    conn.execute("DELETE FROM images WHERE id=?", (image_id,))
    conn.commit()
    conn.close()
    flash("Image deleted", "success")
    return redirect(url_for("index"))

@app.route("/admin")
def admin():
    if "username" not in session or not session.get("is_admin"):
        flash("Admin access only", "danger")
        return redirect(url_for("index"))

    conn = get_db_connection()
    users = conn.execute("SELECT id, username, is_admin, created_at FROM users ORDER BY created_at DESC").fetchall()
    images = conn.execute("SELECT * FROM images ORDER BY uploaded_at DESC").fetchall()
    conn.close()
    return render_template("admin.html", users=users, images=images, username=session.get("username"))

@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    # safe serving of uploaded files
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename, as_attachment=False)

# ------------------ START ------------------
if __name__ == "__main__":
    init_db()
    app.run(debug=True)
